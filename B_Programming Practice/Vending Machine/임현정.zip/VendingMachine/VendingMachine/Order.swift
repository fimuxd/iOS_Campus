//
//  Order.swift
//  VendingMachine
//
//  Created by HyunJomi on 2017. 5. 19..
//  Copyright © 2017년 HyunJung. All rights reserved.
//

import Foundation

class Order
{
    var selectedCountry:[String] = []
   
    var cntOfselected:[String:Int] = ["London": 0, "Paris":0, "Newyork":0, "Sydney":0]//여행지 선택 횟수
    var totalPrice:Int = 0
    //var totalDay = 0
    
    
    
}
