//
//  USDollar.swift
//  VendingMachine
//
//  Created by Bo-Young PARK on 19/5/2017.
//  Copyright © 2017 Bo-Young PARK. All rights reserved.
//

import Foundation

class USDollar {
    var value:Int

    init(value:Int) {
       self.value = value
    }
}
