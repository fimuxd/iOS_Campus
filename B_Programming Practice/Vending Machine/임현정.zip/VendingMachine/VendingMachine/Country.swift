//
//  Country.swift
//  VendingMachine
//
//  Created by HyunJomi on 2017. 5. 19..
//  Copyright © 2017년 HyunJung. All rights reserved.
//

import Foundation

class Country
{

    let name:String
    let budget:Int
    var selected:Int = 0
    
    init(name:String, budget:Int) {
        
        self.name = name
        self.budget = budget
        
    }
    
    
}
