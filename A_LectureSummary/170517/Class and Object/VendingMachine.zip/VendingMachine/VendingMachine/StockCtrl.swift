//
//  VMManager.swift
//  VendingMachine
//
//  Created by Bo-Young PARK on 19/5/2017.
//  Copyright © 2017 Bo-Young PARK. All rights reserved.
//

import Foundation

class StockCtrl {
    init() {
        
    }
    
    func supply(appleAcc:String) {
        
        
    }
}
