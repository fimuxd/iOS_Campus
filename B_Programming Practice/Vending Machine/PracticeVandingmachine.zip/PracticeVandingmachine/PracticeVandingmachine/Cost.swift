//
//  Cost.swift
//  PracticeVandingmachine
//
//  Created by joe on 2017. 5. 21..
//  Copyright © 2017년 joe. All rights reserved.
//

import Foundation

class Cost {
    
    let name : String
    let costValue : Int
    
    init(name : String, costValue : Int){
        
        self.name = name
        self.costValue = costValue
        
    }
    
}
