//
//  ViewController.swift
//  VendingMachine
//
//  Created by 으녕구 on 2017. 5. 19..
//  Copyright © 2017년 eunyeongkim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // printInsertedMoney.text = String(money)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    
    
    
    
    
    
    
    
    
    
    //index 버튼 alert
    @IBAction func indexGP(_ sender: UIButton) {
        let alert = UIAlertController(title: "Green Plugged 2017", message: "장기하와 얼굴들, 볼빨간 사춘기, 국카스텐 등 @난지한강공원", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        }
    
    @IBAction func indexSJF(_ sender: UIButton) {
        let alert = UIAlertController(title: "Seoul Jazz Festival", message: "혼네, 코린베일리 등 @올림픽공원", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func indexUmfK(_ sender: UIButton) {
        let alert = UIAlertController(title: "UMF Korea", message: "Alesso, KSHMR, TIESTO .. @잠실종합운동장", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func indexUmfS(_ sender: UIButton) {
        let alert = UIAlertController(title: "UMF Singapore", message: "Steve Aoki, ShowTek, Pendullum 등 @Singapore", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func indexWcd(_ sender: UIButton) {
        let alert = UIAlertController(title: "World Club Dome Korea", message: "Afrojack, Armin van Buuren, Don diablo .. @인천문학경기장", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func indexMIC(_ sender: UIButton) {
        let alert = UIAlertController(title: "Muse In City 2017", message: "Norah Jones, 코린베일리, 김윤아 등 @올림픽공원", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    //사는 걸 선택하는 button
    @IBAction func buttomGreenPlugged(_ sender: UIButton) {
        let ticketGreenPlugged:Machine = Machine(name: "그린플러그드 2017", date: 0520, cost: 80000)
        if money >= ticketGreenPlugged.cost {
                greenPluggedNumber += 1
                wholeTicketNumber += 1
                money -= ticketGreenPlugged.cost
                printInsertedMoney.text = String(money)
                printTicket.text = ticketGreenPlugged.name + " 티켓이 " + String(greenPluggedNumber) + "장 구매되었습니다. 전체 티켓이 " + String(wholeTicketNumber) + "장 구매되었습니다."
                print(ticketGreenPlugged.name + " 티켓이 구매되었습니다.")
        } else{
                printTicket.text = "잔액이 부족합니다."
                print("잔액이 부족합니다.")}
    }
    
    
    @IBAction func buttonSjf(_ sender: UIButton) {
        let ticketSjf:Machine = Machine(name: "서울 재즈 페스티벌", date: 0527, cost: 140000)
        if money >= ticketSjf.cost {
            sjfNumber += 1
            wholeTicketNumber += 1
            money -= ticketSjf.cost
            printInsertedMoney.text = String(money)
            printTicket.text = ticketSjf.name + " 티켓이" + String(sjfNumber) + "장 구매되었습니다. 전체 티켓이 " + String(wholeTicketNumber) + "장 구매되었습니다."
            print(ticketSjf.name + " 티켓이 구매되었습니다.")
        } else{
            printTicket.text = "잔액이 부족합니다."
            print("잔액이 부족합니다.")}
    }
    
    
    @IBAction func buttonUmfKorea(_ sender: UIButton) {
        let ticketUmfKorea:Machine = Machine(name: "Umf Korea", date: 0610, cost: 100000)
        if umfSingaporeNumber >= 1{
            printTicket.text = "이미 동일한 날짜의 티켓을 구매하셨습니다."
        }else if money >= ticketUmfKorea.cost {
            umfKoreaNumber += 1
            wholeTicketNumber += 1
            money -= ticketUmfKorea.cost
            printInsertedMoney.text = String(money)
            printTicket.text = ticketUmfKorea.name + " 티켓이 " + String(umfKoreaNumber) + "장 구매되었습니다. 전체 티켓이 " + String(wholeTicketNumber) + "장 구매되었습니다."
            print(ticketUmfKorea.name + " 티켓이 구매되었습니다.")
        } else{
            printTicket.text = "잔액이 부족합니다."
            print("잔액이 부족합니다.")}
    }


    @IBAction func buttonUmfSingapore(_ sender: UIButton) {
        let ticketUmfSingapore:Machine = Machine(name: "Umf Singapore", date: 0610, cost: 300000)
        if umfKoreaNumber >= 1{
            printTicket.text = "이미 동일한 날짜의 티켓을 구매하셨습니다."
        }else if money >= ticketUmfSingapore.cost {
            umfSingaporeNumber += 1
            wholeTicketNumber += 1
            money -= ticketUmfSingapore.cost
            printInsertedMoney.text = String(money)
            printTicket.text = ticketUmfSingapore.name + " 티켓이 " + String(umfSingaporeNumber) + "장 구매되었습니다. 전체 티켓이 " + String(wholeTicketNumber) + "장 구매되었습니다."
            print(ticketUmfSingapore.name + " 티켓이 구매되었습니다.")
        } else{
            printTicket.text = "잔액이 부족합니다."
            print("잔액이 부족합니다.")}

    }
    
    
    @IBAction func buttonWcd(_ sender: UIButton) {
        let ticketWorldClubDome:Machine = Machine(name: "World Club Dome Korea", date: 0610, cost: 100000)
        if money >= ticketWorldClubDome.cost {
            wcdNumber += 1
            wholeTicketNumber += 1
            money -= ticketWorldClubDome.cost
            printInsertedMoney.text = String(money)
            printTicket.text = ticketWorldClubDome.name + " 티켓이" + String(wcdNumber) + "장 구매되었습니다. 전체 티켓이 " + String(wholeTicketNumber) + "장 구매되었습니다."
            print(ticketWorldClubDome.name + " 티켓이 구매되었습니다.")
        } else{
            printTicket.text = "잔액이 부족합니다."
            print("잔액이 부족합니다.")}
    }
    
    
    @IBAction func buttonMuseInCity(_ sender: UIButton) {
        let ticketMuseInCity:Machine = Machine(name: "Muse In City", date: 0610, cost: 150000)
        if money >= ticketMuseInCity.cost {
            museInCityNumber += 1
            wholeTicketNumber += 1
            money -= ticketMuseInCity.cost
            printInsertedMoney.text = String(money)
            printTicket.text = ticketMuseInCity.name + " 티켓이" + String(museInCityNumber) + "장 구매되었습니다. 전체 티켓이 " + String(wholeTicketNumber) + "장 구매되었습니다."
            print(ticketMuseInCity.name + " 티켓이 구매되었습니다.")
        } else{
            printTicket.text = "잔액이 부족합니다."
            print("잔액이 부족합니다.")}
    }
    
    // 돈 넣는 버튼들
    @IBAction func buttonMoney10000(_ sender: UIButton) {
        let money10000:insertMoney = insertMoney(iMoney:10000)
        money10000.plusMoney()
        printInsertedMoney.text = String(money)
    }
    
    
    @IBAction func buttonMoney50000(_ sender: UIButton) {
        let money50000:insertMoney = insertMoney(iMoney:50000)
        money50000.plusMoney()
        printInsertedMoney.text = String(money)
    }
    
    
    @IBAction func buttonMoney100000(_ sender: UIButton) {
        let money100000:insertMoney = insertMoney(iMoney:100000)
        money100000.plusMoney()
        printInsertedMoney.text = String(money)
    }
    
    //리셋버튼
    @IBAction func buttonReturnMoney(_ sender: UIButton) {
        greenPluggedNumber = 0
        sjfNumber = 0
        umfKoreaNumber = 0
        umfSingaporeNumber = 0
        wcdNumber = 0
        museInCityNumber = 0
        wholeTicketNumber = 0
        money = 0
        printInsertedMoney.text = "Inserted Money"
        printTicket.text = "Get Ticket!"
    }
    
    //잔액 확인 레이블
    @IBOutlet weak var printInsertedMoney: UILabel!
    
    
    //구매 티켓 확인 레이블
    @IBOutlet weak var printTicket: UILabel!
    
    

}


//변수 정리 

var money:Int = 0 //inserted money
var wholeTicketNumber:Int = 0
var greenPluggedNumber:Int = 0
var sjfNumber:Int = 0
var umfKoreaNumber:Int = 0
var umfSingaporeNumber:Int = 0
var wcdNumber:Int = 0
var museInCityNumber:Int = 0




// 클래스
class Machine {
    let name:String
    let date:Int
    let cost:Int

    
    init(name:String, date:Int, cost:Int) {
        self.name = name
        self.date = date
        self.cost = cost }
}

// 돈 관리 클래스
class insertMoney {
    let iMoney:Int
    init(iMoney:Int) {
        self.iMoney = iMoney
    }
    //돈을 넣는 함수
    func plusMoney() {
        money += self.iMoney
    }
}


