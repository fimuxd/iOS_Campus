//
//  TodayDiaryCell.swift
//  LogInSample
//
//  Created by Bo-Young PARK on 6/7/2017.
//  Copyright © 2017 Bo-Young PARK. All rights reserved.
//

import UIKit

class TodayDiaryCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
