//
//  ViewController.swift
//  VendingMachine
//
//  Created by HyunJomi on 2017. 5. 19..
//  Copyright © 2017년 HyunJung. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var wallet = 0 //잔액
    var money:Int = 0
    var country:[String:Int] = ["London": 100, "Paris":170, "Newyork":150, "Sydney":140]
    
    // 1. dictionary 배열 사용할 경우
    //    let countryArrary:[[String:Any]] = [
    //        ["name":"London", "price":100],
    //        ["name":"Paris", "price":170],
    //        ["name":"Newyork", "price":150],
    //        ["name":"Sydney", "price":140],
    //    ]
    // 2. sender.tag사용할 경우
    
    var orderVal:Order = Order()
    
    @IBOutlet weak var moneyField: UITextField! //돈입력
    @IBOutlet weak var showMyWallet: UILabel!   //현재 가지고 있는 금액 표기
    @IBOutlet weak var showOrderMsgField: UILabel!//선택한 항목 표기
    @IBOutlet weak var showRemainField: UILabel!//잔액 표기
    
    
    @IBOutlet weak var errorLabel: UILabel!

    
    //여행지 선택 시
    @IBAction func countryBtn(_ sender: UIButton) {
        
        let selectedCountry:String = (sender.titleLabel?.text)!//선택한 여행지
        
        //예상 비용, 잔액, 실제 비용
        //잔액과 예상 비용 비교
        var totalTmp = orderVal.totalPrice
        
        totalTmp += country[selectedCountry]!
        
        
         if totalTmp <= wallet
        {
            //여행지 갈 돈 있다면 선택여행지에 추가, 선택 수 추가
            if !orderVal.selectedCountry.contains(selectedCountry)
            {
                orderVal.selectedCountry.append(selectedCountry)
            }
            
            orderVal.cntOfselected[selectedCountry]! += 1
            
            orderVal.totalPrice = totalTmp
            errorLabel.text = ""
        }
        else
        {
            errorLabel.text = "돈없어서 \(selectedCountry) 못감"
            
        }
        
        //showRemainField.text = "\(wallet)"
        
        showCountry()
        
        
        
    }
    
    func showCountry()
    {
        var go:String = ""
        
        for selected in orderVal.selectedCountry
        {
            go += selected
            
            if selected != orderVal.selectedCountry.last {
                go += ", "
            }
        }
        
        
        showOrderMsgField.text = "선택된 여행지 : " + go + "\n"
            + "예상경비 : \(orderVal.totalPrice)"
        
    }
    
    @IBOutlet weak var assetBtn : UIButton!
    //잔액 추가
    @IBAction func assetBtn(_ sender: UIButton)
    {
        
    
        
        if let moreMoney:Int = Int(moneyField.text!)
        {
            wallet += moreMoney
            
            showMyWallet.text = "\(wallet)만원"
            errorLabel.text = ""
        }
        else
        {
            showMyWallet.text = "안생겼다"
            
        }
    
        showRemainField.text = ""
        showOrderMsgField.text = ""
        
    }
    
    @IBAction func resultBtn(_ sender: UIButton) {
        
        //가지고 있는 돈에서 경비 빼기
        var go:String = ""
        
        for selected in orderVal.selectedCountry
        {
            go += selected
            
            if selected != orderVal.selectedCountry.last
            {
                go += ", "
            }
        }
        
        
        wallet -= orderVal.totalPrice
        
        
        showRemainField.text = "\(go)여행 후 \(wallet)만원 남았습니다"
        showMyWallet.text = "\(wallet)만원"
        
        orderVal.selectedCountry = []
        orderVal.totalPrice = 0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.showOrderMsgField.layer.borderWidth = 1
        self.showOrderMsgField.layer.borderColor = UIColor.black.cgColor
        self.showOrderMsgField.layer.cornerRadius = 5
        
        self.showMyWallet.layer.borderWidth = 1
        self.showMyWallet.layer.borderColor = UIColor.black.cgColor
        self.showMyWallet.layer.cornerRadius = 5
        
        self.assetBtn.layer.cornerRadius = 5

        self.errorLabel.textColor = UIColor.red
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

