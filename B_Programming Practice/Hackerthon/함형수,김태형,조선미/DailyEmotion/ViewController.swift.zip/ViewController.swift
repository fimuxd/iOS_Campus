//
//  ViewController.swift
//  HackerTonePractice
//
//  Created by 김태형 on 2017. 7. 6..
//  Copyright © 2017년 김태형. All rights reserved.
//

import UIKit

var sevenDayKey:Bool = false

func emotion(from emotion:[Emotion]) -> String
{
    var happyCount = 0
    var joyCount = 0
    var gladCount = 0
    var breathighCount = 0
    var displeasureCount = 0
    var angerCount = 0
    var melancholyCount = 0
    var sadCount = 0
    for i in emotion
    {
        switch i {
        case .happy:
            happyCount += 1
        case .joy:
            joyCount += 1
        case .glad:
            gladCount += 1
        case .breathigh:
            breathighCount += 1
        case .displeasure:
            displeasureCount += 1
        case .anger:
            angerCount += 1
        case .melancholy:
            melancholyCount += 1
        default:
            sadCount += 1
            
        }
    }
    
    let allArray = [happyCount, joyCount, gladCount, breathighCount, displeasureCount, angerCount, melancholyCount, sadCount]
    
    func intNum(from:[Int]) -> [Int]
    {
        var tempNumArray:[Int] = []
        let maxNum = from.max()!
        var tempNum = 0
        
        for i in 0...from.count - 1
        {
            
            if from[tempNum] == maxNum
            {
                tempNumArray.append(i)
                tempNum += 1
            }else
            {
                tempNum += 1
            }
        }
        return tempNumArray
    }
    let tempNum:[Int] = intNum(from: allArray)
    
    let tempEmotionArray = ["행복한“,”기쁜“,”신나는“,”두근두근한“,”우울한“,”화나는“,”짜증나는“,”슬픈"]
    var realEmotion:String = ""
    
    for i in tempNum
    {
        realEmotion = realEmotion + "\(tempEmotionArray[i]) "
    }
    realEmotion += "날이 많았네요"
    return realEmotion
}
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    var data: User?
    
    
    @IBOutlet weak var tableView: UITableView!
    
    
    
//    let userArray = DataCenter.standard.rawArray
//    var realUser:User?
    let dateFormmater = DateFormatter()
    let date = Date()
    let calender = Calendar.current
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        
        for userInfo in userArray
        {
            if userInfo.userId == UserDefaults.standard.string(forKey: “currentUser”)
            {
                realUser = userInfo
            }
        }
        let timeLineEmotionArray = realUser?.userData
        
        // 최초 다이어리 작성 요일과 현재 요일 같은지 확인하는 곳
        
        let veryFirstUserEmotion = timeLineEmotionArray?.last // save에서 insert(Int: 0)으로 앞으로 save하기 때문에 last가 최초 작성일
        let veryFirstUserDate = veryFirstUserEmotion?.date
        let userDate = dateFormmater.date(from: veryFirstUserDate!)
        if calender.component(.weekday, from: date) == calender.component(.weekday, from: userDate!) && sevenDayKey == false{
            insertSevenDaysEmotion()
            
            sevenDayKey = true
            
        }else if calender.component(.weekday, from: date) != calender.component(.weekday, from: userDate!)
        {
            sevenDayKey = false
        }
        
        
        
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data?.userData.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        
        
        
//        let timeLineEmotionArray = realUser?.userData
//        let cellType = timeLineEmotionArray?[indexPath.row].cellType
        let cellType = data?.userData[indexPath.row].cellType
        let row = data?.userData[indexPath.row].comment
        let name = data?.userId
        
        //if 날짜기준 {
    //}else{
    
        let cell = tableView.dequeueReusableCell(withIdentifier: "normalCell", for: indexPath) as! mainCustomCell
        
        cell.emotionImageView?.image = #imageLiteral(resourceName: "anger")
        cell.userNameLabel.text = data?.userId
        cell.userTodayEmotion.text = convertText(to: (data?.userData[indexPath.row].emotion)!)
        cell.userComment.text = data?.userData[indexPath.row].comment
        cell.backgroundColor = UIColor.clear
        
        return cell
        
        
        
//        switch cellType!
//        {
//        case "0":
//            let cell = tableView.dequeueReusableCell(withIdentifier: "normalCell", for: indexPath) as! mainCustomCell //. as! normalCell
//            // 요부분 cell.~ 로 구현
//            cell.userNameLabel.text = row
//            
//            
//            return cell
//        case "1":
//            let cell = tableView.dequeueReusableCell(withIdentifier: "sevenDayCell", for: indexPath) as! SevenDayTableViewCell
//
//            // 요부분 cell.~로 구현
//            
//            cell.selectionStyle = .none
//            // 요거 아마 셀렉 안 되게 하는 거
//            return cell
//        default:
//            let cell = tableView.dequeueReusableCell(withIdentifier: "normalCell", for: indexPath)
//            return cell
//            
//        }

    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !UserDefaults.standard.bool(forKey: "logInStatus") {
            let logInVC: LogInViewController = self.storyboard?.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
            self.present(logInVC, animated: true, completion: nil)
        }
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        

        
//        tempBool = UserDefaults.standard.bool(forKey: "logInStatus")
        
        if !UserDefaults.standard.bool(forKey: "logInStatus") {
            let logInVC: LogInViewController = self.storyboard?.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
            self.present(logInVC, animated: true, completion: nil)
        }else{
            loadData()
        }
        
        tableView.separatorColor = UIColor.clear
        tableView.backgroundView = UIImageView(image: UIImage(named: "sam-ferrara-270946"))
        
        
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()

        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func loadData() {
        
        let temp = DataCenter.standard.rawArray
        
        
//        if UserDefaults.standard.object(forKey: "currentUser") == nil {
//                let logInVC: LogInViewController = self.storyboard?.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
//                self.present(logInVC, animated: true, completion: nil)
//
//        }
        
        for item in temp {
            if item.userId == UserDefaults.standard.object(forKey: "currentUser") as! String {
                data = item
            }
        }
        
        
    }
    
    func insertSevenDaysEmotion()
    {
        dateFormmater.dateFormat = "yyy MM dd"
        
        let timeLineEmotionArray = realUser?.userData
        
        let veryFirstUserEmotion = timeLineEmotionArray?.last
        
        let veryFirstUserDate = veryFirstUserEmotion?.date
        let userDate = dateFormmater.date(from: veryFirstUserDate!)
        var emotionArray:[Emotion] = []
        
        let days = getDaysArray(start: veryFirstUserDate!, max: getIntervalDays(date: date, anotherDay: userDate))
        
        for timeLineEmotion in timeLineEmotionArray!
        {
            if days.contains(timeLineEmotion.date)
            {
                emotionArray.append(timeLineEmotion.emotion)
            }
        }
        let realEmotion = emotion(from: emotionArray)
    }
    
    func getDaysArray(start: String, max:Int) -> [String] {
        
        var result: [String] = []
        let formatter = DateFormatter()
        formatter.locale = NSLocale(localeIdentifier: "ko_KR") as Locale
        formatter.dateFormat = "yyyy MM dd"
        
        let today = formatter.string(from: Date())
        let startDay = formatter.date(from: start)!
        
        var components = DateComponents()
        let calendar = Calendar(identifier: Calendar.Identifier.gregorian)
        
        for i in 0 ..< max {
            components.setValue(i, for: Calendar.Component.day)
            let week = calendar.date(byAdding: components, to: startDay)!
            let weekStr = formatter.string(from: week)
            if weekStr > today {
                break
            } else {
                result.append(weekStr)
            }
        }
        var realResult:[String] = []
        for _ in 1...7
        {
            realResult.append(result.last!)
            result.removeLast()
            
        }
        
        return realResult
    }
    func getIntervalDays(date: Date?, anotherDay: Date? = nil) -> Int {
        
        var interval: Double!
        
        if anotherDay == nil {
            interval = date?.timeIntervalSinceNow
        } else {
            interval = date?.timeIntervalSince(anotherDay!)
        }
        
        let r = interval / 86400
        
        return Int(floor(r))
    }
    
    func convertText(to rawValue:Emotion) -> String {
        switch rawValue {
        case .joy:
            return "기뻐요 :)"
        case .anger:
            return "화나요 :("
        case .annoyance:
            return "짜증나요 :("
        case .breathigh:
            return "두근두근해요 :)"
        case .displeasure:
            return "우울해요 :("
        case .glad:
            return "신나요 :)"
        case .happy:
            return "행복해요 :)"
        case .melancholy:
            return "짜증나요 :("
        case .sad:
            return "슬퍼요 :("
        case .smile:
            return "웃겨요 :)"
        
        }
    }

}

