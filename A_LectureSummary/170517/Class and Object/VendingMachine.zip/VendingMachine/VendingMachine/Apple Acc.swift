//
//  Apple Acc.swift
//  VendingMachine
//
//  Created by Bo-Young PARK on 19/5/2017.
//  Copyright © 2017 Bo-Young PARK. All rights reserved.
//

import Foundation

class AppleAcc {
    var name:String
    var price:Int
    
    init(name:String, price:Int) {
        self.name = name
        self.price = price
    }
    
}
