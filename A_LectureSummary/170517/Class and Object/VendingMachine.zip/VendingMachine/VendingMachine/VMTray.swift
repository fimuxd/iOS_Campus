//
//  VMTray.swift
//  VendingMachine
//
//  Created by Bo-Young PARK on 19/5/2017.
//  Copyright © 2017 Bo-Young PARK. All rights reserved.
//

import Foundation

class VMTray {
    var tray:[AppleAcc]
    
    init(tray:[AppleAcc]) {
        self.tray = tray
    }
    
    
}
